#load ground truth file

#sample groundtruth文件的格式如下：

#每一行是一个query对应的ground truth。格式为：

#query \t groundtruth1 空格 groundtruth2 空格 groundtruth3 空格 groundtruth4 ...

#每个query的groundtruth的个数可能不同，可能是大于等于1的任意整数。所以每行的长度也不同。

#groundtruth 实际上文件行数 = query文件行数，即包含所有1000个query

#提供的示例goundtruth仅用于格式说明与验证，不是实际评测用的groundtruth

query=list()
groundtruth=list()

with open('sample_groundtruth.txt', 'r') as f:
    while True:
        line = f.readline()     
        if not line:
            break
        q=line.split('\t')[0]
        truth=set(line.split('\t')[1][:-1].split(' '))
        query.append(q)
        groundtruth.append(truth)

print("There are in totally %d queries.\n"%len(query))


#load sample submission
num_of_q=0
mAP=0  
with open('sample_submission.txt','r') as g:
    while True:
        q=g.readline()
        if not q:
            break
        if q[0]=='#':
            continue
        if q[:-1]!=query[num_of_q]:
            print("input error: query mismatch:")
            print(q[:-1])
            print("Num %d\n"%(num_of_q+1))
            break
        
        num_of_answer=0
        num_of_correct=0
        AP=0
        while num_of_answer<10:
            ans=g.readline()
            if ans[0]=='#':
                continue
            ans_at_point=ans.split(' ')[1][:-1]
            num_of_answer=num_of_answer+1
            if ans_at_point in groundtruth[num_of_q]:
                num_of_correct=num_of_correct+1
                AP=AP+float(num_of_correct)/num_of_answer

        mAP=mAP+AP/len(groundtruth[num_of_q])
        num_of_q=num_of_q+1

    if num_of_q!=0:
        mAP=mAP/num_of_q
        print("On %d queries, You get mAP of %f \n"%(num_of_q,mAP))
    else:
        print("On 0 query, You get mAP of 0 \n")
    
        


